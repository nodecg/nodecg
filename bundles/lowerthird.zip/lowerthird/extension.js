module.exports = function (nodecg) {
  nodecg.Replicant('lowerthird_line1', { defaultValue: 'Your Name' });
  nodecg.Replicant('lowerthird_line2', { defaultValue: 'Your Title' });
};
